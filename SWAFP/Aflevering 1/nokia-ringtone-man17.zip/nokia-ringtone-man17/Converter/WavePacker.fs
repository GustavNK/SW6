﻿module WavePacker

open System.IO
open System.Text

// TODO 7 Write data to stream
// http://soundfile.sapp.org/doc/WaveFormat/
// subchuncksize 16
// audioformat: 1s
// num channels: 1s
// sample rate: 44100
// byte rate: sample rate *16/8
// block origin: 2s
// bits per sample: 16s
let pack (d: int16[]) =
    let stream = new MemoryStream()
    let writer = new BinaryWriter(stream, Encoding.ASCII)
    let dataLength = Array.length d*2   
    
    // RIFF
    writer.Write("RIFF"B) //chunkID
    writer.Write(36 + 16) //ChunkSize
    writer.Write("WAVE"B) //Format

    // fmt
    writer.Write("fmt "B)
    writer.Write(16) //Subchunk1Size
    writer.Write(1s) //AudioFormat
    writer.Write(1s) //NumChannels
    writer.Write(44100) //SampleRate
    writer.Write(44100 * 2) //ByteRate
    writer.Write(2s) //BlockAlign
    writer.Write(16s) //BitsPerSample
    
    // data
    writer.Write("data"B) //Subchunk2ID
    writer.Write(dataLength) //Subchunk2Size
    
    for sound in d do
        writer.Write(sound)

    stream
    
let Write filename (ms: MemoryStream) =
    use fs = new FileStream(Path.Combine(__SOURCE_DIRECTORY__, filename), FileMode.Create) // use IDisposible
    ms.WriteTo(fs)
