﻿
open System

// TODO 8 take input from file/cmd and save it to a file
[<EntryPoint>]
let main argv =
    let score = argv[1]
    
    match Assembler.assembleToPackedStream score with
            | Choice2Of2 ms -> WavePacker.Write "BeautifulMusicFile.wav" ms
            | Choice1Of2 err -> failwith err
    Console.WriteLine("File has been saved")
    0