# TODO 
## Schema
- Opsæt de nødvendige queries
- Opsæt de nødvendige mutations

### Types
- definer reservation
- definer room
- definer user
## Postgres api setup
- Lav de nødvendige 


# Krav
- Flere attributter for værelser
- Implementer queries og mutations for disse
- Have samme struktur som assignment 1 men ingen krav om login = ingen krav om permissions